const express = require("express");
const { connect } = require("http2");
const app = express();
const path = require("path");
const port = 3000;

var ipConnections = {};
var threshold = 5;

app.set("trust proxy", true);

app.use((req, res, next) => {
  // Tenta pegar o IP real, mesmo atrás de proxy (ex: nginx, Heroku)
  const ip = req.headers["x-forwarded-for"] || req.socket.remoteAddress;

  console.log(ip);

  // Conta as conexões por IP
  if (ipConnections[ip]) {
    ipConnections[ip]++;
  } else {
    ipConnections[ip] = 1;
  }

  if ((ipConnections = 5)) {
    console.log(ipConnections[ip]);
    console.log("Treshold de ip atingido");
    ipConnections = 0;
    process.exit();
  } else {
    console.log(`IP ${ip} fez ${ipConnections[ip]} requisições`);
  }

  next();
});

app.get("/", (req, res) => {
  const ip = req.headers["x-forwarded-for"] || req.socket.remoteAddress;
  res.send(`Você já fez ${ipConnections[ip]} requisições a partir deste IP.`);
});

// Serve arquivos estáticos da pasta "public"
app.use(express.static(path.join(__dirname, "public")));

// Define a rota para a raiz que serve o index.html
app.get("/", function (req, res) {
  res.sendFile(path.join(__dirname, "public", "index.html"));
});

// Start the server
app.listen(port, () => {
  console.log(`Server listening at http://localhost:${port}`);
});
